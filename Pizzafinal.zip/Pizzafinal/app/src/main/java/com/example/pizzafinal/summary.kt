package com.example.pizzafinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class summary: AppCompatActivity() {

    lateinit var size: EditText
    lateinit var top: EditText
    lateinit var bill: EditText
    lateinit var piz: EditText
    lateinit var n: EditText
    lateinit var p: EditText




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)


        bill = findViewById(R.id.AMOUNT)
        size=findViewById(R.id.SIZE)
        top=findViewById(R.id.TOP)
         piz=findViewById(R.id.pizza)
        n=findViewById<View>(R.id.NAME) as EditText
         p=findViewById<View>(R.id.PHNO) as EditText




        val amt = intent.getStringExtra("AMOUNT")
        val Size = intent.getStringExtra("SIZE")
        val Top = intent.getStringExtra("TOP")
        val pizza = intent.getStringExtra("PIZZA")
        val name = intent.getStringExtra("NAME")
        val pHNO = intent.getStringExtra("PHNO")




        bill.setText(amt.toString())
        size.setText(Size.toString())
        top.setText(Top.toString())
        piz.setText(pizza.toString())
        n.setText(name.toString())
        p.setText(pHNO.toString())


    }

}