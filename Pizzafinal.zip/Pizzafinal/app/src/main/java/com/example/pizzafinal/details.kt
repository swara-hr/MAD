package com.example.pizzafinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class details : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

    }

    fun save(V: View) {
        var u = findViewById<View>(R.id.Name) as EditText
        var p = findViewById<View>(R.id.no) as EditText

        if (u.text.toString().isEmpty()) {
            Toast.makeText(this, " PLEASE ENTER YOUR NAME", Toast.LENGTH_LONG).show()
        }
        else if (p.text.toString().isEmpty()) {
            Toast.makeText(this, " PLEASE ENTER YOUR NUMBER", Toast.LENGTH_LONG).show()
        }
        else if(p.text.toString().length!=10) {

            Toast.makeText(this, " PLEASE ENTER VALID PHONE NUMBER", Toast.LENGTH_LONG).show()
        }
            else
          {

            val buttonClick2: Button = findViewById<Button>(R.id.SAVE) as Button
            buttonClick2.setOnClickListener {

                var i = Intent(this, pizza::class.java)
                i.putExtra("NAME", u.text.toString())
                i.putExtra("PHNO", p.text.toString())
                startActivity(i)
            }
        }
    }
}










