package com.example.pizzafinal

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class pizza : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pizza)


    }


    fun click(v: View?) {
        var b = v as Button
        var txt = b.text
        var c = findViewById<View>(R.id.ch) as TextView
        c.setText(txt.toString())
    }

    fun ok(V: View?) {

        var pizza = findViewById<View>(R.id.ch) as TextView
        if (pizza.text.toString().isEmpty()) {
            Toast.makeText(this, " PLEASE SELECT PIZZA", Toast.LENGTH_LONG).show()
        } else {
            val name = intent.getStringExtra("NAME")
            val phno = intent.getStringExtra("PHNO")


            val buttonClick: Button = findViewById<Button>(R.id.OK) as Button
            buttonClick.setOnClickListener {
                val i2 = Intent(this, customize::class.java)
                i2.putExtra("NAME", name)
                i2.putExtra("PHNO", phno)
                i2.putExtra("PIZZA", pizza.text.toString())
                startActivity(i2)
            }
        }
    }
}








