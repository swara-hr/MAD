package com.example.pizzafinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import com.example.pizzafinal.summary

class customize : AppCompatActivity() {
    lateinit var rs:RadioButton
    lateinit var rm:RadioButton
    lateinit var rl:RadioButton
    lateinit var onions:RadioButton
    lateinit var olives:RadioButton
    lateinit var tomatoes:RadioButton
    lateinit var tvtotalbill:TextView
    lateinit var BTNORDER:Button
    lateinit var rg1:RadioGroup
    lateinit var rg2:RadioGroup
    lateinit var rb1:RadioButton
    lateinit var rb2:RadioButton
    var totalbill=0.0f







    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customize)
        rs=findViewById(R.id.rs)
        rm=findViewById(R.id.rm)
        rl=findViewById(R.id.rl)
        olives=findViewById(R.id.olive)
        onions=findViewById(R.id.onions)
        tomatoes=findViewById(R.id.tomatoes)
        BTNORDER=findViewById(R.id.BTNORDER)
        tvtotalbill=findViewById(R.id.tvtotalbill)
        rg1=findViewById(R.id.radioGroup)
        rg2=findViewById(R.id.radioGroup1)
        val selectedOption=rg1.checkedRadioButtonId
        val selectedOption2=rg2.checkedRadioButtonId
        rb1=findViewById(selectedOption)
        rb2=findViewById(selectedOption2)








        BTNORDER.setOnClickListener {
            if(totalbill<=0.0) {
                Toast.makeText(this," PLEASE SELECT PIZZA!!!",Toast.LENGTH_LONG).show()

            }

            else
            {

                val name= intent.getStringExtra("NAME")
                val phno = intent.getStringExtra("PHNO")
                val pizza = intent.getStringExtra("PIZZA")
                startActivity(
                    Intent(this, summary::class.java)

                        .putExtra("AMOUNT", tvtotalbill.text.toString())
                        .putExtra("SIZE", rb1.text.toString())
                        .putExtra("TOP", rb2.text.toString())
                        .putExtra("NAME",name)
                        .putExtra("PHNO",phno)
                        .putExtra("PIZZA",pizza)

                )

            }

        }
    }
    fun placeorder(view: View)
    {
        var pizzasizeprice=0.0f
        var pizzatoppingsprice=0.0f



        when{
            rs.isChecked->pizzasizeprice+=300.0f
            rm.isChecked->pizzasizeprice+=400.0f
            rl.isChecked->pizzasizeprice+=500.0f

        }
        when{

            olives.isChecked->pizzatoppingsprice+=150.0f
            onions.isChecked->pizzatoppingsprice+=100.0f
            tomatoes.isChecked->pizzatoppingsprice+=70.0f

        }
        totalbill=pizzasizeprice+pizzatoppingsprice
        tvtotalbill.setText(" Rs"+totalbill)
    }


}


